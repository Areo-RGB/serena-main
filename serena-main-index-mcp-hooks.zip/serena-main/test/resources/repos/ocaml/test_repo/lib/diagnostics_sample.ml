let broken_factory (
