def brokenFactory : Nat :=
